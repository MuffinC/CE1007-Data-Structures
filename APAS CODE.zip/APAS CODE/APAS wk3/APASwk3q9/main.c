#include <stdio.h>
int perfectProd1(int num);
void perfectProd2(int num, int *prod);
int main()
{
    int number, result=0;
    printf("Enter a number: \n");
    scanf("%d", &number);
    printf("Calling perfectProd1() \n");
    printf("perfectProd1(): %d\n", perfectProd1(number));
    printf("Calling perfectProd2() \n");
    perfectProd2(number, &result);
    printf("perfectProd2(): %d\n", result);
    return 0;
}
int perfectProd1(int num)
{ int factor=1,result=0,pnum=1,counter=1;
    while(counter<=num){
        for(int i=1;i<counter;i++){
            if(counter==1){
                break;
            }
            if(counter%i==0){
                factor=i;
                result=result+factor;
            }
        }
        if (result==counter && counter !=1){
            printf("Perfect number: %d\n",result);
            pnum=pnum*result;
        }
        result=0;
        counter++;
    }
    return pnum;
}
void perfectProd2(int num, int *prod)
{
    int factor=1,result=0,pnum=1,counter=1;
    while(counter<=num){
        for(int i=1;i<counter;i++){
            if(counter==1){
                break;
            }
            if(counter%i==0){
                factor=i;
                result=result+factor;
            }
        }
        if (result==counter && counter !=1){
            printf("Perfect number: %d\n",result);
            pnum=pnum*result;
        }
        result=0;
        counter++;
    }
    *prod=pnum;
    return;
}
