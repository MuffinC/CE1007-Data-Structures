#include <stdio.h>
int divide1(int m, int n, int *r);
void divide2(int m, int n, int *q, int *r);
int main()
{
    int m, n, q, r;
    printf("Enter two numbers (m and n): \n");
    scanf("%d %d", &m, &n);
    q = divide1(m, n, &r);
    printf("divide1(): quotient %d remainder %d\n", q, r);
    divide2(m, n, &q, &r);
    printf("divide2(): quotient %d remainder %d\n", q, r);
    return 0;
}
int divide1(int m, int n, int *r) {
    int resultant = 0, remainder,quotient=0;
    if (m>=n){
        while (resultant <= m) {
            resultant = resultant + n;
            quotient++;
        }
        quotient-=1;
        resultant-=n;
        remainder = m - resultant;
        *r = remainder;
        return quotient;
    }
    quotient=0;
    *r=m;
    return quotient;

}
void divide2(int m, int n, int *q, int *r)
{
    int resultant = 0, remainder,quotient=0;
    if (m>=n){
        while (resultant <= m) {
            resultant = resultant + n;
            quotient++;
        }
        quotient-=1;
        resultant-=n;
        remainder = m - resultant;
        *r = remainder;
        *q=quotient;
        return;
    }
    quotient=0;
    *r=m;
    *q=quotient;
}