#include <stdio.h>
double computePay1(int noOfHours, int payRate);
void computePay2(int noOfHours, int payRate, double *grossPay);
int main()
{
    int noOfHours, payRate;
    double grossPay;

    printf("Enter number of hours: \n");
    scanf("%d", &noOfHours);
    printf("Enter hourly pay rate: \n");
    scanf("%d", &payRate);
    printf("computePay1(): %.2f\n", computePay1(noOfHours, payRate));
    computePay2(noOfHours, payRate, &grossPay);
    printf("computePay2(): %.2f\n", grossPay);
    return 0;
}
double computePay1(int noOfHours, int payRate)
{
    double grosspay;
    int timeleft;
    if ((noOfHours>=0) && (noOfHours<=160)){
        grosspay=noOfHours*payRate;
    }
    else{
        grosspay=160*payRate;
        payRate=payRate*1.5;
        timeleft=noOfHours-160;
        grosspay=grosspay+(payRate*timeleft);
    }
    return grosspay;
}
void computePay2(int noOfHours, int payRate, double *grossPay)
{
    double grosspay1;
    int timeleft;
    if ((noOfHours>=0) && (noOfHours<=160)){
        grosspay1=noOfHours*payRate;
    }
    else{
        grosspay1=160*payRate;
        payRate=payRate*1.5;
        timeleft=noOfHours-160;
        grosspay1=grosspay1+(payRate*timeleft);
    }
    *grossPay=grosspay1;
}