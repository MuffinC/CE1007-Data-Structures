#include <stdio.h>
float power1(float num, int p);
void power2(float num, int p, float *result);
int main()
{
    int power;
    float number, result=-1;
    printf("Enter the number and power: \n");
    scanf("%f %d", &number, &power);
    printf("power1(): %.2f\n", power1(number, power));
    power2(number,power,&result);
    printf("power2(): %.2f\n", result);
    return 0;
}
float power1(float num, int p)
{
    int count=0,uval=num,result=1,posval;
    float ans;
    if(p>=1){
        while(count<p){
            result=result*uval;
            count++;
        }
        return result;
    }
    else if(p==0){
        return 1.00;
    }
    else if(p<0){
        posval=p*-1;
        while(count<=posval){
            result=result*uval;
            count++;
        }
       ans= num/result;
        return ans;
    }

}
void power2(float num, int p, float *result)
{
    int count=0,uval=num,resultant=1,posval;
    float ans;
    if(p>=1){
        while(count<p){
            resultant=resultant*uval;
            count++;
        }
        *result=resultant;
    }
    else if(p==0){
        resultant=1.00;
        *result=resultant;
    }
    else if(p<0){
        posval=p*-1;
        while(count<=posval){
            resultant=resultant*uval;
            count++;
        }
        ans= num/resultant;
        *result=ans;
    }
}