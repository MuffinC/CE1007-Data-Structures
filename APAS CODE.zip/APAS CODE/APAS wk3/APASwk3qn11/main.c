#include <stdio.h>
int reverseDigits1(int num);
void reverseDigits2(int num, int *result);
int main()
{
    int num, result=999;
    printf("Enter a number: \n");
    scanf("%d", &num);
    printf("reverseDigits1(): %d\n", reverseDigits1(num));
    reverseDigits2(num, &result);
    printf("reverseDigits2(): %d\n", result);
    return 0;
}
int reverseDigits1(int num)
{
int result=0,val1,val2=num,tens=1;
if(num<10){
    return num;
}
while(num>=1){
    num/=10;
    tens=tens*10;
}
while(tens>=1){
    val1=val2%10;
    result=result+(val1*tens);
    tens=tens/10;
    val2/=10;
}
return result;
}
void reverseDigits2(int num, int *result)
{
    int val3=0,val1,val2=num,tens=1;
    if(num<10){
        *result=num;
        return;
    }
    while(num>1){
        num/=10;
        tens=tens*10;
    }
    while(tens>=1){
        val1=val2%10;
        val3=val3+(val1*tens);
        tens=tens/10;
        val2/=10;
    }
    *result=val3;
    return;
}