#include <stdio.h>
#define INIT_VALUE 999
int extEvenDigits1(int num);
void extEvenDigits2(int num, int *result);
int main()
{
    int number, result = INIT_VALUE;
    printf("Enter a number: \n");
    scanf("%d", &number);
    printf("extEvenDigits1(): %d\n", extEvenDigits1(number));
    extEvenDigits2(number, &result);
    printf("extEvenDigits2(): %d\n", result);
    return 0;
}
int extEvenDigits1(int num)
{
int mod1,result=0,tens=1;
while(num>=1){
    mod1=num%10;
    if (mod1%2==0){
    result=result+(mod1*tens);
    tens=tens*10;
}
    num=num/10;
}
if(result==0){
    return -1;
}
return result;
}
void extEvenDigits2(int num, int *result)
{
    int mod1,val1=0,tens=1;
    while(num>=1){
        mod1=num%10;
        if (mod1%2==0){
            val1=val1+(mod1*tens);
            tens=tens*10;
        }
        num=num/10;
    }
    if(val1==0){
        *result=-1;
        return;
    }
    *result=val1;
    return;
}