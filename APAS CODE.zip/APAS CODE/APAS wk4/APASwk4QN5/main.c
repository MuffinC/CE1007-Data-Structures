#include <stdio.h>
int platform1D(int ar[], int size);
int main()
{
    int i,b[50],size;
    printf("Enter array size: \n");
    scanf("%d", &size);
    printf("Enter %d data: \n", size);
    for (i=0; i<size; i++)
        scanf("%d",&b[i]);
    printf("platform1D(): %d\n", platform1D(b,size));
    return 0;
}
int platform1D(int ar[], int size) {
    int hold1 = 0, adder = 0, counter1 = 1,hold2=1,counter2=1;
    for (adder; adder < size; adder++) {
        if (hold1 == ar[adder]) {
            if(counter1==1){
                hold2=hold1;
            }
            if(hold1!=hold2){
                counter2++;
            }
            if(hold1==hold2){
                counter1++;
            }
        }
        hold1 = ar[adder];
    }
    if(counter2>counter1){
        return counter2;
    }
    return counter1;
}