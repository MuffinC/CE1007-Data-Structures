#include <stdio.h>
#define SIZE 100
void compress2D(int data[SIZE][SIZE], int rowSize, int colSize);
int main()
{
    int data[SIZE][SIZE];
    int i,j;
    int rowSize, colSize;
    printf("Enter the array size (rowSize, colSize): \n");
    scanf("%d %d", &rowSize, &colSize);
    printf("Enter the matrix (%dx%d): \n", rowSize, colSize);
    for (i=0; i<rowSize; i++)
        for (j=0; j<colSize; j++)
            scanf("%d", &data[i][j]);
    printf("compress2D(): \n");
    compress2D(data, rowSize, colSize);
    return 0;
}
void compress2D(int data[SIZE][SIZE], int rowSize, int colSize)
{
int i=0,j=0,start=0,count=1;
for(i;i<rowSize;i++){
    j=0;
    start= data[i][j];
    count=1;
    for(j;j<colSize;j++){
        if(j==0){
            start=data[i][j];
        }
        if(data[i][j]==start && j!=0){
            count+=1;
        }
        if(data[i][j]!=start){
            printf("%d %d ",start,count);
            count=1;
            start=data[i][j];
        }
    }
    printf("%d %d",start,count);
    printf("\n");
}
}