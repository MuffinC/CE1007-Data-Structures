#ifndef APASWK4QN9_LIBRARY_H
#define APASWK4QN9_LIBRARY_H

void hello(void);

#endif //APASWK4QN9_LIBRARY_H
