#include <stdio.h>
#define SIZE 100
void compress2D(int data[SIZE][SIZE], int rowSize, int colSize);
int main()
{
    int data[SIZE][SIZE];
    int i,j;
    int rowSize, colSize;
    printf("Enter the array size (rowSize, colSize): \n");
    scanf("%d %d", &rowSize, &colSize);
    printf("Enter the matrix (%dx%d): \n", rowSize, colSize);
    for (i=0; i<rowSize; i++)
        for (j=0; j<colSize; j++)
            scanf("%d", &data[i][j]);
    printf("compress2D(): \n");
    compress2D(data, rowSize, colSize);
    return 0;
}
void compress2D(int data[SIZE][SIZE], int rowSize, int colSize)
{
int i=0,j=0,counter=0,pos=0,checker;
for(i;i<colSize;i++){
    pos=0;
    checker=data[0][0];
    for(int j=0;j<rowSize;j++){
        if(j==0){
            checker=data[i][j];
        }
        if(checker==data[i][j]){
            counter++;
        }
        if(checker!=data[i][j]){
            data[i][pos]=checker;
            data[i][pos+1]=counter;

            checker=data[i][j];
        }
    }
}


for (i; i < rowSize; i++) {
    j = 0;
    for (j; j < colSize; j++) {
        printf("%d ", data[i][j]);
    }
    printf("\n");
    }
}
