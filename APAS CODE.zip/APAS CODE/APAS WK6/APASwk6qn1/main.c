#include <stdio.h>
#include <string.h> //NEED TO INSERT THIS HEADER
typedef struct {
    char name[20];
    int age;
} Person;
void readData(Person *p);
Person findMiddleAge(Person *p);
int main()
{
    Person man[3], middle;
    readData(man);
    middle = findMiddleAge(man);
    printf("findMiddleAge(): %s %d\n", middle.name, middle.age);
    return 0;
}
void readData(Person *p)
{
printf("Enter person 1:\n");
scanf("%s %d",&p[0].name,&p[0].age);
printf("Enter person 2:\n");
    scanf("%s %d",&p[1].name,&p[1].age);
printf("Enter person 3:\n");
    scanf("%s %d",&p[2].name,&p[2].age);
}
Person findMiddleAge(Person *p)
{ Person place;
    int maxage=p[0].age,count=0,maxcount=0,leastage=p[0].age,middleage=0;
    for(count;count<3;count++){
        if(p[count].age>maxage){
            maxage=p[count].age;
        }
    }
    for(count=0;count<3;count++){
        if(p[count].age<maxage && p[count].age>leastage){
            middleage=count;
        }
        else{
            middleage=0;
        }

    }
    strcpy(place.name,p[middleage].name);
    place.age=p[middleage].age;
return place;

}