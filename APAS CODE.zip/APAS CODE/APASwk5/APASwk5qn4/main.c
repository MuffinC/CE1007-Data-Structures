#include <stdio.h>
#include <string.h>
int countWords(char *s);
int main()
{
    char str[50], *p;
    printf("Enter the string: \n");
    fgets(str, 80, stdin);
    if (p=strchr(str,'\n')) *p = '\0';
    printf("countWords(): %d", countWords(str));
    return 0;
}
int countWords(char *s)
{int breakcount=1,i=0;
while(i<strlen(s)){
    if(s[i]==' '){
        breakcount++;
    }
    i++;
}
return breakcount;
}