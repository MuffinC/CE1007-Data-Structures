#include <stdio.h>
#include <string.h>
void insertChar(char *str1, char *str2, char ch);
int main()
{
    char a[80],b[80];
    char ch, *p;
    printf("Enter a string: \n");
    fgets(a, 80, stdin);
    if (p=strchr(a,'\n')) *p = '\0';
    printf("Enter a character to be inserted: \n");
    ch = getchar();
    insertChar(a,b,ch);
    printf("insertChar(): ");
    puts(b);
    return 0;
}
void insertChar(char *str1, char *str2, char ch)
{
int counter=0,stri=0,stri2=0;
int size=strlen(str1);
while(stri2<=size){

    if(counter==3){
        str2[stri]=ch;
        counter=0;
        stri++;
    }
    else {
        str2[stri]=str1[stri2];
        stri++;
        stri2++;
        counter++;
    }

}
}