#include <stdio.h>
#include <string.h>
#define INIT_VALUE -1
int countSubstring(char str[], char substr[]);
int main()
{
    char str[80], substr[80], *p;
    int result=INIT_VALUE;
    printf("Enter the string: \n");
    fgets(str, 80, stdin);
    if (p=strchr(str,'\n')) *p = '\0';
    printf("Enter the substring: \n");
    fgets(substr, 80, stdin);
    if (p=strchr(substr,'\n')) *p = '\0';
    result = countSubstring(str, substr);
    printf("countSubstring(): %d\n", result);
    return 0;
}
int countSubstring(char str[], char substr[])
{
    int i=0,j=0,strcount=0,substrcount=0,counter=0,end=0;
    while(str[j]!='\0'){
        strcount++;
        j++;
    }
    j=0;
    while(substr[j]!='\0'){
        substrcount++;
        j++;
    }
    j=0;

    for(j;j<strcount;j++){
        if(substr[i]==str[j]){
            counter++;
            i++;
            if(counter==substrcount){
                end++;
                i=0;
                counter=0;
            }
        }
        else {
            if(j!=(strcount-1) && str[j]==substr[0]){
                continue;
            }
            i=0;
            counter=0;
        }
    }
    return end;
}