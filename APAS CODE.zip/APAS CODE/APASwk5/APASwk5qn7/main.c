#include <stdio.h>
#include <string.h>
#define SIZE 10
void findMinMaxStr(char word[][40], char *first, char *last, int
size);
int main()
{
    char word[SIZE][40];
    char first[40], last[40];
    int i, size;
    printf("Enter size: \n");
    scanf("%d", &size);
    printf("Enter %d words: \n", size);
    for (i=0; i<size; i++)
        scanf("%s", word[i]);
    findMinMaxStr(word, first, last, size);
    printf("First word = %s, Last word = %s\n", first, last);
    return 0;
}
void findMinMaxStr(char word[][40], char *first, char *last, int
size)
{int i=0,j=0,storelow=0,storehigh=0;
char compare1=word[0][0],compare2=word[0][0],compare3=word[0][0],compare4=word[0][0],result1,result2;


for(i;i<size;i++){
    if(i>0){
        compare2=word[i][0];
        compare4=word[i][0];
        if(compare2>compare1){
            compare1=compare2;
            storehigh=i;
        }
        if(compare4<compare3){
            compare3=compare4;
            storelow=i;
        }
    }
}
if(i==1){
    strcpy(last,word[0]);
    strcpy(first,word[0]);
}
else{
    strcpy(last,word[storehigh]);
    strcpy(first,word[storelow]);
}
}